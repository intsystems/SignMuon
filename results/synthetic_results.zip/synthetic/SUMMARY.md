# Synthetic benchmark results

Run 2026-07-29 03:40:11 — NVIDIA RTX A4000, torch 2.7.0+cu128, commit `<redacted for review>`

| stage | exit | minutes |
| :--- | :--- | ---: |
| stability | 0 | 1.7 |
| alignment | 0 | 2.0 |
| floor | 0 | 35.7 |
| horizon | 0 | 11.7 |
| kappa | 0 | 16.5 |
| grid | 0 | 7.4 |
| final | 0 | 3.1 |

## Tuned comparison (`tab:synthetic_tuned`)

`100x100`, spectrum `uniform`, basis `haar`, L = 0.9905, sigma = 2.713e-05, condition number = 3.65e+04, lmo_dtype `bfloat16`, seeds [1337, 1338, 1339], X0 seed 42, runner `batched`

| method | iterations to target | best F | min ‖∇F‖ | lr | momentum | schedule | on grid boundary |
| :--- | ---: | ---: | ---: | ---: | ---: | :--- | :--- |
| signmuon | 364 | 6.933e-04 | 2.444e-02 | 0.001 | 0 | const | — |
| ef21signmuon | 401 | 5.370e-04 | 2.060e-02 | 0.006813 | 0 | const | — |
| muonusign | 556 | 7.082e-04 | 2.297e-02 | 0.01 | 0.5 | const | — |
| muonsign | 595 | 4.841e-04 | 1.938e-02 | 0.0006813 | 0.5 | const | — |
| ef21muonusign | 521 | 5.258e-04 | 1.806e-02 | 0.006813 | 0 | const | — |
| ef21muonsign | 695 | 3.842e-04 | 1.717e-02 | 0.004642 | 0 | const | — |
| muon | 267 | 4.688e-04 | 2.036e-02 | 0.01 | 0.5 | const | — |
| signsgd | 486 | 4.316e-04 | 2.179e-02 | 0.0006813 | 0.5 | const | — |
| sgd | 66 | 1.902e-08 | 1.628e-06 | 2.154 | 0.5 | const | — |
| adam | 85 | 9.214e-06 | 6.491e-04 | 0.06813 | -- | const | — |

## Re-run at the tuned optima (`fig:synthetic_main`)

`100x100`, spectrum `uniform`, basis `haar`, L = 0.9905, sigma = 2.713e-05, condition number = 3.65e+04, lmo_dtype `bfloat16`, seeds [1337, 1338, 1339], X0 seed 42, runner `batched`

| method | iterations to target | best F | min ‖∇F‖ | lr | momentum | schedule | on grid boundary |
| :--- | ---: | ---: | ---: | ---: | ---: | :--- | :--- |
| signmuon | 364 | 6.933e-04 | 2.444e-02 | 0.001 | 0 | const | — |
| ef21signmuon | 401 | 5.370e-04 | 2.060e-02 | 0.006813 | 0 | const | — |
| muonusign | 556 | 7.082e-04 | 2.297e-02 | 0.01 | 0.5 | const | — |
| muonsign | 595 | 4.841e-04 | 1.938e-02 | 0.0006813 | 0.5 | const | — |
| ef21muonusign | 521 | 5.258e-04 | 1.806e-02 | 0.006813 | 0 | const | — |
| ef21muonsign | 695 | 3.842e-04 | 1.717e-02 | 0.004642 | 0 | const | — |
| muon | 267 | 4.688e-04 | 2.036e-02 | 0.01 | 0.5 | const | — |
| signsgd | 486 | 4.316e-04 | 2.179e-02 | 0.0006813 | 0.5 | const | — |
| sgd | 66 | 1.902e-08 | 1.628e-06 | 2.154 | 0.5 | const | — |
| adam | 85 | 9.214e-06 | 6.491e-04 | 0.06813 | -- | const | — |

## Gradient/step alignment

`rho_t = <grad F(X_t), d_t> / (||grad F(X_t)||_F ||d_t||_F)`. The descent lemma needs it positive; the divergence theorems make it negative. The reference column is the closed form for `d = compressor(grad F)` at `X_0` with no momentum, so it is only comparable to a row whose tuned momentum is 0. A `†` marks a value censored at its grid edge: an upper bound rather than a tuned optimum.

`100x100`, spectrum `uniform`, basis `haar`, L = 0.9905, sigma = 2.713e-05, condition number = 3.65e+04, lmo_dtype `bfloat16`, seeds [1337, 1338, 1339], X0 seed 42, runner `batched`

| method | min rho | 1st pct | median | mean | % negative | closed form | tuned |
| :--- | ---: | ---: | ---: | ---: | ---: | ---: | :--- |
| signmuon | 0.2076 | 0.2206 | 0.3814 | 0.3985 | 0.00% | -- | eta=0.0002154, mu=0 |
| ef21signmuon | 0.3329 | 0.3495 | 0.6591 | 0.5728 | 0.00% | -- | eta=0.001468, mu=0 |
| muonusign | 0.1611 | 0.1673 | 0.3568 | 0.3776 | 0.00% | -- | eta=0.003162, mu=0 |
| muonsign | 0.1422 | 0.1513 | 0.3595 | 0.3638 | 0.00% | -- | eta=0.0002154, mu=0 |
| ef21muonusign | 0.3459 | 0.3505 | 0.5582 | 0.5527 | 0.00% | -- | eta=0.001468, mu=0 |
| ef21muonsign | -0.0258 | -0.0122 | 0.4894 | 0.4189 | 0.95% | -- | eta=0.001468, mu=0 |
| muon | 0.4535 | 0.4607 | 0.6655 | 0.6328 | 0.00% | 0.6949 | eta=0.001468, mu=0 |
| signsgd | 0.1740 | 0.1755 | 0.5030 | 0.4985 | 0.00% | 0.7939 | eta=0.0002154, mu=0.5 |
| sgd | — | — | — | — | — | 1.0000 | eta=3.162, mu=0.95 |
| adam | — | — | — | — | — | -- | eta=0.003162, mu=0 |

## Accuracy floor of a constant step

Slope of `log(plateau)` against `log(eta)`. The descent lemma predicts the gradient floor is linear in `eta` (slope 1) with coefficient `L||s||_F^2 / (2 rho)`. SignMuon and SignSGD share `||s||_F^2 = mn` exactly, so any gap between their floors is attributable to `rho` alone.

`100x100`, spectrum `uniform`, basis `haar`, L = 0.9905, sigma = 2.713e-05, condition number = 3.65e+04, lmo_dtype `bfloat16`, seeds [1337, 1338, 1339], X0 seed 42, runner `batched`

| method | settled points | d log‖∇F‖/d log η | R² | d log F/d log η | R² | L‖s‖²/2 |
| :--- | :--- | ---: | ---: | ---: | ---: | ---: |
| signmuon | 7/7 | 1.000 | 1.000 | 2.000 | 1.000 | 4953 |
| ef21signmuon | 7/7 | 1.000 | 1.000 | 2.000 | 1.000 | 49.53 |
| muonusign | 7/7 | 1.000 | 1.000 | 2.000 | 1.000 | 49.53 |
| muonsign | 7/7 | 1.000 | 1.000 | 2.000 | 1.000 | 4953 |
| ef21muonusign | 7/7 | 1.000 | 1.000 | 2.000 | 1.000 | 49.53 |
| ef21muonsign | 7/7 | 1.000 | 1.000 | 2.000 | 1.000 | 49.53 |
| muon | 7/7 | 1.000 | 1.000 | 2.000 | 1.000 | 49.53 |
| signsgd | 7/7 | 0.989 | 1.000 | 1.334 | 1.000 | 4953 |
| sgd | 0/7 | no floor | | | | -- |
| adam | 4/7 | 1.000 | 1.000 | 2.001 | 1.000 | -- |

<details><summary>Per-η plateaus</summary>

**signmuon**

| η | iterations | F∞ | ‖∇F‖∞ | settled |
| ---: | ---: | ---: | ---: | :--- |
| 6e-05 | 60000 | 2.6480e-06 | 1.5269e-03 | yes |
| 0.0001076 | 55743 | 8.5184e-06 | 2.7389e-03 | yes |
| 0.0001931 | 31072 | 2.7419e-05 | 4.9135e-03 | yes |
| 0.0003464 | 17321 | 8.8241e-05 | 8.8158e-03 | yes |
| 0.0006214 | 9655 | 2.8403e-04 | 1.5814e-02 | yes |
| 0.001115 | 5382 | 9.1374e-04 | 2.8367e-02 | yes |
| 0.002 | 3000 | 2.9422e-03 | 5.0900e-02 | yes |

**ef21signmuon**

| η | iterations | F∞ | ‖∇F‖∞ | settled |
| ---: | ---: | ---: | ---: | :--- |
| 0.0006 | 60000 | 4.4610e-06 | 1.8964e-03 | yes |
| 0.001076 | 55743 | 1.4360e-05 | 3.4025e-03 | yes |
| 0.001931 | 31072 | 4.6209e-05 | 6.1041e-03 | yes |
| 0.003464 | 17321 | 1.4878e-04 | 1.0952e-02 | yes |
| 0.006214 | 9655 | 4.7848e-04 | 1.9642e-02 | yes |
| 0.01115 | 5382 | 1.5409e-03 | 3.5246e-02 | yes |
| 0.02 | 3000 | 4.9589e-03 | 6.3215e-02 | yes |

**muonusign**

| η | iterations | F∞ | ‖∇F‖∞ | settled |
| ---: | ---: | ---: | ---: | :--- |
| 0.0006 | 60000 | 2.4605e-06 | 1.3031e-03 | yes |
| 0.001076 | 55743 | 7.9212e-06 | 2.3379e-03 | yes |
| 0.001931 | 31072 | 2.5487e-05 | 4.1936e-03 | yes |
| 0.003464 | 17321 | 8.2047e-05 | 7.5234e-03 | yes |
| 0.006214 | 9655 | 2.6389e-04 | 1.3494e-02 | yes |
| 0.01115 | 5382 | 8.4998e-04 | 2.4215e-02 | yes |
| 0.02 | 3000 | 2.7348e-03 | 4.3440e-02 | yes |

**muonsign**

| η | iterations | F∞ | ‖∇F‖∞ | settled |
| ---: | ---: | ---: | ---: | :--- |
| 6e-05 | 60000 | 3.6531e-06 | 1.6560e-03 | yes |
| 0.0001076 | 55743 | 1.1760e-05 | 2.9708e-03 | yes |
| 0.0001931 | 31072 | 3.7842e-05 | 5.3288e-03 | yes |
| 0.0003464 | 17321 | 1.2184e-04 | 9.5611e-03 | yes |
| 0.0006214 | 9655 | 3.9194e-04 | 1.7155e-02 | yes |
| 0.001115 | 5382 | 1.2610e-03 | 3.0769e-02 | yes |
| 0.002 | 3000 | 4.0595e-03 | 5.5207e-02 | yes |

**ef21muonusign**

| η | iterations | F∞ | ‖∇F‖∞ | settled |
| ---: | ---: | ---: | ---: | :--- |
| 0.0006 | 60000 | 4.3012e-06 | 1.6559e-03 | yes |
| 0.001076 | 55743 | 1.3847e-05 | 2.9706e-03 | yes |
| 0.001931 | 31072 | 4.4544e-05 | 5.3285e-03 | yes |
| 0.003464 | 17321 | 1.4342e-04 | 9.5593e-03 | yes |
| 0.006214 | 9655 | 4.6138e-04 | 1.7151e-02 | yes |
| 0.01115 | 5382 | 1.4865e-03 | 3.0766e-02 | yes |
| 0.02 | 3000 | 4.7775e-03 | 5.5198e-02 | yes |

**ef21muonsign**

| η | iterations | F∞ | ‖∇F‖∞ | settled |
| ---: | ---: | ---: | ---: | :--- |
| 0.0006 | 60000 | 6.8022e-06 | 2.3211e-03 | yes |
| 0.001076 | 55743 | 2.1881e-05 | 4.1632e-03 | yes |
| 0.001931 | 31072 | 7.0461e-05 | 7.4696e-03 | yes |
| 0.003464 | 17321 | 2.2682e-04 | 1.3399e-02 | yes |
| 0.006214 | 9655 | 7.3019e-04 | 2.4044e-02 | yes |
| 0.01115 | 5382 | 2.3478e-03 | 4.3116e-02 | yes |
| 0.02 | 3000 | 7.5548e-03 | 7.7362e-02 | yes |

**muon**

| η | iterations | F∞ | ‖∇F‖∞ | settled |
| ---: | ---: | ---: | ---: | :--- |
| 0.0006 | 60000 | 1.5652e-06 | 1.2569e-03 | yes |
| 0.001076 | 55743 | 5.0365e-06 | 2.2547e-03 | yes |
| 0.001931 | 31072 | 1.6212e-05 | 4.0454e-03 | yes |
| 0.003464 | 17321 | 5.2167e-05 | 7.2561e-03 | yes |
| 0.006214 | 9655 | 1.6793e-04 | 1.3019e-02 | yes |
| 0.01115 | 5382 | 5.4055e-04 | 2.3357e-02 | yes |
| 0.02 | 3000 | 1.7398e-03 | 4.1906e-02 | yes |

**signsgd**

| η | iterations | F∞ | ‖∇F‖∞ | settled |
| ---: | ---: | ---: | ---: | :--- |
| 6e-05 | 60000 | 1.8764e-04 | 2.7547e-03 | yes |
| 0.0001076 | 55743 | 4.0760e-04 | 4.9293e-03 | yes |
| 0.0001931 | 31072 | 8.3354e-04 | 8.7204e-03 | yes |
| 0.0003464 | 17321 | 1.8928e-03 | 1.5696e-02 | yes |
| 0.0006214 | 9655 | 4.2059e-03 | 2.7865e-02 | yes |
| 0.001115 | 5382 | 9.2035e-03 | 4.9714e-02 | yes |
| 0.002 | 3000 | 1.9775e-02 | 8.8383e-02 | yes |

**sgd**

| η | iterations | F∞ | ‖∇F‖∞ | settled |
| ---: | ---: | ---: | ---: | :--- |
| 0.006 | 60000 | 7.9893e-04 | 2.2355e-03 | no |
| 0.01076 | 55743 | 2.7958e-04 | 1.0690e-03 | no |
| 0.01931 | 31072 | 2.7957e-04 | 1.0689e-03 | no |
| 0.03464 | 17321 | 2.7955e-04 | 1.0689e-03 | no |
| 0.06214 | 9655 | 2.7954e-04 | 1.0688e-03 | no |
| 0.1115 | 5382 | 2.7955e-04 | 1.0688e-03 | no |
| 0.2 | 3000 | 2.7950e-04 | 1.0686e-03 | no |

**adam**

| η | iterations | F∞ | ‖∇F‖∞ | settled |
| ---: | ---: | ---: | ---: | :--- |
| 0.0006 | 60000 | 1.1599e-06 | 1.4423e-03 | yes |
| 0.001076 | 55743 | 3.7358e-06 | 2.5898e-03 | yes |
| 0.001931 | 31072 | 1.2027e-05 | 4.6396e-03 | yes |
| 0.003464 | 17321 | 3.8747e-05 | 8.3319e-03 | yes |
| 0.006214 | 9655 | 1.2365e-04 | 1.4905e-02 | no |
| 0.01115 | 5382 | 3.3877e-04 | 2.4412e-02 | no |
| 0.02 | 3000 | 8.3664e-04 | 3.7767e-02 | no |

</details>

## Budget scaling

Tuned separately at each budget `T`, then fitted. `p` is fitted on `min_t ‖∇F(X_t)‖_*²`, the squared dual norm the theorems bound — ℓ1 for the sign family, nuclear for the LMO family; the Frobenius column is the same trajectory in a family-independent norm. `p = q = 1/2` is the nonconvex L-smooth regime the theorems prove, `p = q = 1` the strongly convex one. SGD has no floor, so no power law fits it. A `†` marks a value censored at its grid edge: an upper bound rather than a tuned optimum.

`100x100`, spectrum `uniform`, basis `haar`, L = 0.9905, sigma = 2.713e-05, condition number = 3.65e+04, lmo_dtype `bfloat16`, seeds [1337, 1338, 1339], X0 seed 42, runner `batched`

| method | dual | p (‖∇F‖_*²) | R² | p (‖∇F‖_F) | R² | p (F) | R² | q (η*) | R² |
| :--- | :--- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| signmuon | l1 | 1.881 | 0.996 | 0.983 | 0.995 | 2.449 | 0.916 | 0.388 | 0.942 |
| ef21signmuon | nuclear | 2.068 | 1.000 | 1.041 | 1.000 | 1.082 | 0.821 | 0.554 | 1.000 |
| muonusign | nuclear | 1.861 | 0.995 | 0.917 | 0.994 | 2.177 | 0.980 | 0.388 | 0.942 |
| muonsign | l1 | 1.926 | 0.993 | 0.919 | 0.993 | 1.484 | 0.884 | 0.443 | 0.941 |
| ef21muonusign | nuclear | 2.039 | 1.000 | 1.009 | 0.999 | 1.103 | 0.964 | 0.554 | 1.000 |
| ef21muonsign | nuclear | 2.141 | 1.000 | 1.070 | 1.000 | 2.142 | 1.000 | 0.554 | 1.000 |
| muon | nuclear | 2.025 | 0.999 | 1.030 | 0.999 | 0.863 | 0.705 | 0.554 | 1.000 |
| signsgd | l1 | 1.763 | 0.990 | 0.904 | 0.994 | 1.975 | 0.892 | 0.388 | 0.942 |
| sgd | fro | 8.968 | 0.985 | 4.484 | 0.985 | 7.656 | 0.974 | -0.111 | 0.500 |
| adam | fro | 2.651 | 0.915 | 1.325 | 0.915 | 1.420 | 0.716 | -0.664 | 0.621 |

<details><summary>Per-budget optima</summary>

**signmuon**

| T | η* | momentum | schedule | best F | min ‖∇F‖_F | min ‖∇F‖_* |
| ---: | ---: | ---: | :--- | ---: | ---: | ---: |
| 125 | 0.01468 | 0 | sqrt | 6.2028e-03 | 3.7851e-02 | 2.8718e+00 |
| 250 | 0.01 | 0 | sqrt | 5.7103e-03 | 2.2968e-02 | 1.5563e+00 |
| 500 | 0.01 | 0 | sqrt | 1.4472e-04 | 1.1170e-02 | 9.0644e-01 |
| 1000 | 0.006813 | 0 | sqrt | 3.5424e-05 | 5.3881e-03 | 4.3472e-01 |
| 2000 | 0.004642 | 0 | sqrt | 1.6250e-05 | 2.5868e-03 | 2.0875e-01 |

**ef21signmuon**

| T | η* | momentum | schedule | best F | min ‖∇F‖_F | min ‖∇F‖_* |
| ---: | ---: | ---: | :--- | ---: | ---: | ---: |
| 125 | 0.1468 | 0 | sqrt | 2.3172e-03 | 4.1296e-02 | 2.9728e-01 |
| 250 | 0.1 | 0 | sqrt | 5.7002e-04 | 1.9694e-02 | 1.4212e-01 |
| 500 | 0.06813 | 0 | sqrt | 1.7665e-04 | 9.3969e-03 | 6.8604e-02 |
| 1000 | 0.04642 | 0 | sqrt | 9.4609e-05 | 4.5614e-03 | 3.3055e-02 |
| 2000 | 0.03162 | 0 | sqrt | 1.3394e-04 | 2.3229e-03 | 1.7131e-02 |

**muonusign**

| T | η* | momentum | schedule | best F | min ‖∇F‖_F | min ‖∇F‖_* |
| ---: | ---: | ---: | :--- | ---: | ---: | ---: |
| 125 | 0.2154 | 0 | sqrt | 7.5777e-03 | 4.3091e-02 | 3.3062e-01 |
| 250 | 0.1468 | 0 | sqrt | 3.7807e-03 | 2.2252e-02 | 1.7321e-01 |
| 500 | 0.1468 | 0 | sqrt | 3.7778e-04 | 1.4134e-02 | 1.0534e-01 |
| 1000 | 0.1 | 0 | sqrt | 9.3095e-05 | 6.7547e-03 | 5.0658e-02 |
| 2000 | 0.06813 | 0 | sqrt | 2.5554e-05 | 3.2611e-03 | 2.4325e-02 |

**muonsign**

| T | η* | momentum | schedule | best F | min ‖∇F‖_F | min ‖∇F‖_* |
| ---: | ---: | ---: | :--- | ---: | ---: | ---: |
| 125 | 0.01468 | 0 | sqrt | 1.6122e-02 | 4.7477e-02 | 3.1946e+00 |
| 250 | 0.01468 | 0 | sqrt | 1.9458e-03 | 2.5595e-02 | 2.0630e+00 |
| 500 | 0.01 | 0 | sqrt | 6.1588e-04 | 1.2311e-02 | 9.9270e-01 |
| 1000 | 0.006813 | 0 | sqrt | 2.7512e-04 | 6.0978e-03 | 4.7800e-01 |
| 2000 | 0.004642 | 0 | sqrt | 2.5036e-04 | 4.0220e-03 | 2.3595e-01 |

**ef21muonusign**

| T | η* | momentum | schedule | best F | min ‖∇F‖_F | min ‖∇F‖_* |
| ---: | ---: | ---: | :--- | ---: | ---: | ---: |
| 125 | 0.1468 | 0 | sqrt | 6.3408e-03 | 3.7153e-02 | 2.8996e-01 |
| 250 | 0.1 | 0 | sqrt | 2.2472e-03 | 1.7815e-02 | 1.3979e-01 |
| 500 | 0.06813 | 0 | sqrt | 9.7023e-04 | 8.6683e-03 | 6.8057e-02 |
| 1000 | 0.04642 | 0 | sqrt | 4.0347e-04 | 4.2754e-03 | 3.3385e-02 |
| 2000 | 0.03162 | 0 | sqrt | 3.2678e-04 | 2.2960e-03 | 1.7321e-02 |

**ef21muonsign**

| T | η* | momentum | schedule | best F | min ‖∇F‖_F | min ‖∇F‖_* |
| ---: | ---: | ---: | :--- | ---: | ---: | ---: |
| 125 | 0.2154 | 0 | sqrt | 9.0712e-03 | 7.5486e-02 | 5.6069e-01 |
| 250 | 0.1468 | 0 | sqrt | 2.1737e-03 | 3.6972e-02 | 2.6144e-01 |
| 500 | 0.1 | 0 | sqrt | 4.7145e-04 | 1.7000e-02 | 1.2439e-01 |
| 1000 | 0.06813 | 0 | sqrt | 1.0484e-04 | 8.1912e-03 | 5.9798e-02 |
| 2000 | 0.04642 | 0 | sqrt | 2.4656e-05 | 3.9343e-03 | 2.8699e-02 |

**muon**

| T | η* | momentum | schedule | best F | min ‖∇F‖_F | min ‖∇F‖_* |
| ---: | ---: | ---: | :--- | ---: | ---: | ---: |
| 125 | 0.1468 | 0 | sqrt | 7.5853e-04 | 2.7118e-02 | 1.8297e-01 |
| 250 | 0.1 | 0 | sqrt | 2.0195e-04 | 1.3026e-02 | 8.5325e-02 |
| 500 | 0.06813 | 0 | sqrt | 6.7919e-05 | 6.1632e-03 | 4.1392e-02 |
| 1000 | 0.04642 | 0 | sqrt | 4.5092e-05 | 2.9916e-03 | 2.0765e-02 |
| 2000 | 0.03162 | 0 | sqrt | 8.0602e-05 | 1.5940e-03 | 1.1102e-02 |

**signsgd**

| T | η* | momentum | schedule | best F | min ‖∇F‖_F | min ‖∇F‖_* |
| ---: | ---: | ---: | :--- | ---: | ---: | ---: |
| 125 | 0.01468 | 0.5 | sqrt | 3.4748e-03 | 4.3152e-02 | 3.4948e+00 |
| 250 | 0.01 | 0.5 | sqrt | 1.7379e-03 | 2.2473e-02 | 1.7045e+00 |
| 500 | 0.006813 | 0.5 | sqrt | 1.4273e-03 | 1.4157e-02 | 8.3466e-01 |
| 1000 | 0.006813 | 0.5 | sqrt | 6.3671e-05 | 6.9999e-03 | 5.8160e-01 |
| 2000 | 0.004642 | 0.5 | sqrt | 1.9311e-05 | 3.3654e-03 | 2.8213e-01 |

**sgd**

| T | η* | momentum | schedule | best F | min ‖∇F‖_F | min ‖∇F‖_* |
| ---: | ---: | ---: | :--- | ---: | ---: | ---: |
| 125 | 2.154 | 0.5 | const | 2.5762e-04 | 1.0049e-03 | 1.0049e-03 |
| 250 | 3.162 | 0.9 | const | 3.4243e-07 | 1.3252e-05 | 1.3252e-05 |
| 500 | 3.162 | 0.9 | const | 4.6981e-08 | 2.8836e-06 | 2.8836e-06 |
| 1000 | 3.162 | 0.95 | const | 7.1662e-11 | 8.4402e-08 | 8.4405e-08 |
| 2000 | 3.162 | 0.95 | const | 5.3405e-14 | 2.2425e-09 | 2.2426e-09 |

**adam**

| T | η* | momentum | schedule | best F | min ‖∇F‖_F | min ‖∇F‖_* |
| ---: | ---: | ---: | :--- | ---: | ---: | ---: |
| 125 | 0.03162 | -- | const | 2.4738e-04 | 2.4699e-03 | 2.4699e-03 |
| 250 | 0.03162 | -- | const | 2.0910e-05 | 3.7030e-04 | 3.7031e-04 |
| 500 | 0.02154 | -- | const | 4.8960e-06 | 3.1976e-04 | 3.2118e-04 |
| 1000 | 0.1468 | -- | sqrt | 1.8754e-05 | 1.7535e-04 | 1.7535e-04 |
| 2000 | 0.1468 | -- | sqrt | 1.9022e-06 | 3.6309e-05 | 3.6309e-05 |

</details>

## Step-size stability edge

L = 0.9905, so `2/L` = 2.019. **SGD is the control** — its `eta_max` must land on `2/L`. If the operative trust region were the Frobenius ball, `eta_max*||s||_F` would be family-independent and also near `2/L`; the spread measures how far off the Frobenius bound is for each step geometry.

`100x100`, spectrum `uniform`, basis `haar`, L = 0.9905, sigma = 2.713e-05, condition number = 3.65e+04, lmo_dtype `bfloat16`, seeds [1337, 1338, 1339], X0 seed 42, runner `batched`

A `>` means the search hit its ceiling without finding an edge, so that row is a lower bound, not a measurement. Adam lands there by construction: its step is bounded by roughly `lr` whatever the gradient does, so it oscillates instead of diverging.

| method | η_max | ‖s‖_F | η_max·‖s‖_F | ÷ (2/L) |
| :--- | ---: | ---: | ---: | ---: |
| signmuon | 0.1343 | 100 | 13.43 | 6.651 |
| ef21signmuon | 1.894 | 10 | 18.94 | 9.380 |
| muonusign | 1.486 | 10 | 14.86 | 7.360 |
| muonsign | 0.1184 | 100 | 11.84 | 5.866 |
| ef21muonusign | 1.491 | 10 | 14.91 | 7.385 |
| ef21muonsign | 1.491 | 10 | 14.91 | 7.385 |
| muon | 1.758 | 10 | 17.58 | 8.706 |
| signsgd | 0.1114 | 100 | 11.14 | 5.516 |
| sgd | 2.063 | — | — | 1.022 |
| adam | &gt; 100 | — | — | 49.525 |

## Condition-number sweep

Best `‖∇F‖` reached within the budget, tuned at each κ. Spectra are log-spaced with `L = 1`, so κ is exact. A `†` marks a value censored at its grid edge: an upper bound rather than a tuned optimum.

`100x100`, spectrum `uniform`, basis `haar`, L = 1, sigma = 1e-06, condition number = 1e+06, lmo_dtype `bfloat16`, seeds [1337, 1338, 1339], X0 seed 42, runner `batched`

| method | κ=10 | κ=100 | κ=1000 | κ=10000 | κ=100000 | κ=1e+06 | d log‖∇F‖/d log κ | R² |
| :--- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| signmuon | 4.000e-03 | 2.210e-03 | 1.689e-03 | 1.426e-03 | 1.146e-03 | 7.958e-04 | -0.127 | 0.958 |
| ef21signmuon | 3.733e-03 | 1.856e-03 | 1.146e-03 | 7.985e-04 | 6.211e-04 | 4.858e-04 | -0.172 | 0.955 |
| muonusign | 5.305e-03 | 2.890e-03 | 2.094e-03 | 1.657e-03 | 1.107e-03 | 9.964e-04 | -0.142 | 0.960 |
| muonsign | 6.316e-03 | 3.905e-03 | 2.394e-03 | 1.653e-03 | 1.304e-03 | 8.925e-04 | -0.167 | 0.986 |
| ef21muonusign | 4.997e-03 | 1.645e-03 | 1.081e-03 | 8.592e-04 | 7.377e-04 | 6.249e-04 | -0.162 | 0.832 |
| ef21muonsign | 1.096e-02 | 2.484e-03 | 1.714e-03 | 1.832e-03 | 1.529e-03 | 1.317e-03 | -0.149 | 0.671 |
| muon | 2.080e-03 | 1.254e-03 | 9.728e-04 | 7.990e-04 | 6.964e-04 | 6.522e-04 | -0.096 | 0.905 |
| signsgd | 4.573e-03 | 3.898e-03 | 3.203e-03 | 1.871e-03 | 1.291e-03 | 7.163e-04 | -0.163 | 0.957 |
| sgd | 2.154e-22 | 1.772e-22 | 1.285e-20 | 1.991e-15 | 1.823e-07 | 3.850e-07 | 3.614 | 0.894 |
| adam | 5.366e-06 | 4.083e-07 | 2.586e-11 | 3.612e-06 | 2.786e-05 | 3.610e-05 | 0.422 | 0.118 |

<details><summary>Per-κ optima</summary>

**signmuon**

| κ | η* | momentum | schedule | iterations | min ‖∇F‖ |
| ---: | ---: | ---: | :--- | ---: | ---: |
| 10 | 0.0001468 | 0 | const | 2335 | 3.9997e-03 |
| 100 | 0.0001468 | 0 | const | 2158 | 2.2095e-03 |
| 1000 | 0.0001468 | 0 | const | 2081 | 1.6894e-03 |
| 10000 | 0.0001468 | 0 | const | 2028 | 1.4261e-03 |
| 100000 | 0.0001 | 0.5 | const | 2768 | 1.1464e-03 |
| 1e+06 | 0.0001 | 0.5 | const | 2326 | 7.9581e-04 |

**ef21signmuon**

| κ | η* | momentum | schedule | iterations | min ‖∇F‖ |
| ---: | ---: | ---: | :--- | ---: | ---: |
| 10 | 0.001 | 0 | const | 2086 | 3.7330e-03 |
| 100 | 0.001 | 0 | const | 2332 | 1.8563e-03 |
| 1000 | 0.001 | 0 | const | 2440 | 1.1460e-03 |
| 10000 | 0.001 | 0 | const | 2337 | 7.9846e-04 |
| 100000 | 0.001 | 0 | const | 2353 | 6.2114e-04 |
| 1e+06 | 0.001 | 0 | const | 2096 | 4.8583e-04 |

**muonusign**

| κ | η* | momentum | schedule | iterations | min ‖∇F‖ |
| ---: | ---: | ---: | :--- | ---: | ---: |
| 10 | 0.002154 | 0 | const | 2352 | 5.3052e-03 |
| 100 | 0.002154 | 0 | const | 2165 | 2.8903e-03 |
| 1000 | 0.002154 | 0.5 | const | 2052 | 2.0938e-03 |
| 10000 | 0.001468 | 0 | const | 2767 | 1.6569e-03 |
| 100000 | 0.001468 | 0.5 | const | 2468 | 1.1075e-03 |
| 1e+06 | 0.001468 | 0 | const | 2199 | 9.9635e-04 |

**muonsign**

| κ | η* | momentum | schedule | iterations | min ‖∇F‖ |
| ---: | ---: | ---: | :--- | ---: | ---: |
| 10 | 0.0002154 | 0 | const | 1909 | 6.3159e-03 |
| 100 | 0.0002154 | 0 | const | 1820 | 3.9053e-03 |
| 1000 | 0.0001468 | 0.5 | const | 2454 | 2.3942e-03 |
| 10000 | 0.0001468 | 0.5 | const | 2206 | 1.6529e-03 |
| 100000 | 0.0001 | 0.5 | const | 2875 | 1.3041e-03 |
| 1e+06 | 0.0001 | 0 | const | 2675 | 8.9254e-04 |

**ef21muonusign**

| κ | η* | momentum | schedule | iterations | min ‖∇F‖ |
| ---: | ---: | ---: | :--- | ---: | ---: |
| 10 | 0.001468 | 0 | const | 1847 | 4.9971e-03 |
| 100 | 0.001 | 0 | const | 2409 | 1.6447e-03 |
| 1000 | 0.001 | 0 | const | 2473 | 1.0811e-03 |
| 10000 | 0.001 | 0 | const | 2398 | 8.5916e-04 |
| 100000 | 0.001 | 0 | const | 2481 | 7.3765e-04 |
| 1e+06 | 0.001 | 0 | const | 2242 | 6.2489e-04 |

**ef21muonsign**

| κ | η* | momentum | schedule | iterations | min ‖∇F‖ |
| ---: | ---: | ---: | :--- | ---: | ---: |
| 10 | 0.002154 | 0 | const | 1802 | 1.0960e-02 |
| 100 | 0.001 | 0 | const | 2497 | 2.4838e-03 |
| 1000 | 0.001 | 0 | const | 2630 | 1.7137e-03 |
| 10000 | 0.001468 | 0 | const | 1868 | 1.8319e-03 |
| 100000 | 0.001468 | 0 | const | 1931 | 1.5290e-03 |
| 1e+06 | 0.001468 | 0 | const | 1543 | 1.3175e-03 |

**muon**

| κ | η* | momentum | schedule | iterations | min ‖∇F‖ |
| ---: | ---: | ---: | :--- | ---: | ---: |
| 10 | 0.001 | 0 | const | 2085 | 2.0800e-03 |
| 100 | 0.001 | 0.5 | const | 2331 | 1.2543e-03 |
| 1000 | 0.001 | 0.5 | const | 2433 | 9.7281e-04 |
| 10000 | 0.001 | 0.5 | const | 2324 | 7.9898e-04 |
| 100000 | 0.001 | 0.5 | const | 2341 | 6.9644e-04 |
| 1e+06 | 0.001 | 0.5 | const | 2087 | 6.5215e-04 |

**signsgd**

| κ | η* | momentum | schedule | iterations | min ‖∇F‖ |
| ---: | ---: | ---: | :--- | ---: | ---: |
| 10 | 0.0001468 | 0.5 | const | 2320 | 4.5733e-03 |
| 100 | 0.0001468 | 0.9 | const | 2118 | 3.8981e-03 |
| 1000 | 0.0001468 | 0.95 | const | 1826 | 3.2028e-03 |
| 10000 | 0.0001 | 0.99† | const | 2367 | 1.8712e-03 |
| 100000 | 0.0001 | 0.99† | const | 2116 | 1.2915e-03 |
| 1e+06 | 6.813e-05 | 0.99† | const | 2600 | 7.1629e-04 |

**sgd**

| κ | η* | momentum | schedule | iterations | min ‖∇F‖ |
| ---: | ---: | ---: | :--- | ---: | ---: |
| 10 | 0.1468 | 0 | const | 167 | 2.1539e-22 |
| 100 | 0.6813 | 0.5 | const | 91 | 1.7720e-22 |
| 1000 | 0.4642 | 0.95 | const | 150 | 1.2852e-20 |
| 10000 | 3.162 | 0.95 | const | 145 | 1.9909e-15 |
| 100000 | 1.468 | 0.99† | const | 663 | 1.8229e-07 |
| 1e+06 | 3.162 | 0.99† | const | 649 | 3.8501e-07 |

**adam**

| κ | η* | momentum | schedule | iterations | min ‖∇F‖ |
| ---: | ---: | ---: | :--- | ---: | ---: |
| 10 | 0.003162 | -- | const | 206 | 5.3662e-06 |
| 100 | 0.03162 | -- | const | 77 | 4.0833e-07 |
| 1000 | 0.02154 | -- | const | 85 | 2.5863e-11 |
| 10000 | 0.004642 | -- | const | 427 | 3.6124e-06 |
| 100000 | 0.004642 | -- | const | 475 | 2.7862e-05 |
| 1e+06 | 0.003162 | -- | const | 619 | 3.6104e-05 |

</details>


# Overnight run report

* started `2026-07-29T03:17:48`, wall clock 1 day, 10:13:10 elapsed, no deadline (Ctrl-C to stop)
* device `cuda:0`, resnet18 / cifar10, measured **12.9 s/epoch**
* machine: Experiments were run on NVIDIA RTX A4500 (19.6 GB) with a AMD Ryzen 9 5950X 16-Core Processor, 32 cores and 62.7 GB of system memory. Software: Linux 5.15.0-139-generic, Python 3.12.11, PyTorch 2.5.1+cu124, CUDA 12.4, driver 560.35.05.
* scaling rule **`unit-gain`**, `--head-adamw always`, lr_aux = 0.001, momentum 0.9, weight decay 0 (decoupled)
* eta_0 selected at **75 epochs**, the horizon the table reports, on the 45k/5k split, on **val_acc** (tail mean of 5); the test set was not used for any decision

## Gain diagnostic (measures the exponent directly)

Growth of the accumulated update's RMS gain `||X_t - X_0||_F / sqrt(fan_out)` against the epoch count, at a **constant** learning rate (with annealing the accumulation saturates and the slope would measure the schedule instead).

A slope near **0.5** means successive sign steps stay incoherent, supporting `unit-gain` (alpha=1/2); near **1.0** means they align, supporting `mup` (alpha=1).

| run | fitted slope | R^2 | epochs used | reading |
| :--- | ---: | ---: | ---: | :--- |
| `gain_muon_e20_t` | 0.512 | 0.999 | 20 | incoherent -> alpha=1/2 |
| `gain_muonsign_e20_t` | 0.561 | 0.999 | 20 | incoherent -> alpha=1/2 |
| `gain_signmuon_e20_t` | 0.515 | 1.000 | 20 | incoherent -> alpha=1/2 |
| `gain_signsgd_e20_t` | 0.490 | 1.000 | 20 | incoherent -> alpha=1/2 |

## Auxiliary rate (is `lr_aux` method-independent?)

Best `val_acc` over the eta_0 grid at each `lr_aux`, 15 epochs. The comparison is between the **columns' argmaxes**: both methods are measured at the same horizon, so a horizon bias cancels here in a way it does not for eta_0.

| method | 0.0001 | 0.0002 | 0.0005 | 0.001 | 0.002 | argmax |
| :--- | ---: | ---: | ---: | ---: | ---: | ---: |
| `signmuon` | 93.25 | 93.18 | 93.27 | 93.52 | 93.23 | 0.001 |
| `muon` | 93.32 | 93.22 | 93.29 | 93.27 | 93.43 | 0.002 |

**DISAGREE** -- the optimum depends on the matrix rule, so `lr_aux` must be tuned per method at an equal 2-D budget.

## Tuned eta_0 (75 epochs, validation)

| method | eta_0 | val acc | configs | note |
| :--- | ---: | ---: | ---: | :--- |
| `signmuon` | 0.02 | 94.29% | 5 |  |
| `muonusign` | 0.02 | 94.18% | 5 |  |
| `muonsign` | 0.1 | 93.44% | 5 |  |
| `ef21signmuon` | 0.02 | 94.77% | 5 |  |
| `ef21muonusign` | 0.05 | 94.22% | 7 |  |
| `ef21muonsign` | 0.005 | 93.90% | 5 |  |
| `muon` | 0.1 | 94.65% | 7 |  |
| `signsgd` | 0.002 | 93.23% | 9 |  |
| `sgd` | 0.02 | 93.15% | 5 |  |
| `adam` | 0.001 | 93.28% | 5 |  |

A `BOUNDARY` note means the optimum sat on a grid endpoint and the grid ran out of extension rounds: widen it and re-run that method before reporting it.

## Final runs (full 50k, test set)

| run | test acc (tail mean) | epochs to target |
| :--- | ---: | ---: |
| `adam_unit-gain_e75_fs0` | 93.60% | 20 |
| `adam_unit-gain_e75_fs1` | 93.45% | 20 |
| `adam_unit-gain_e75_fs2` | 93.07% | 20 |
| `ef21muonsign_unit-gain_e75_fs0` | 93.93% | 10 |
| `ef21muonsign_unit-gain_e75_fs1` | 94.12% | 12 |
| `ef21muonsign_unit-gain_e75_fs2` | 94.07% | 11 |
| `ef21muonusign_unit-gain_e75_fs0` | 94.17% | 10 |
| `ef21muonusign_unit-gain_e75_fs1` | 94.07% | 11 |
| `ef21muonusign_unit-gain_e75_fs2` | 94.20% | 10 |
| `ef21signmuon_unit-gain_e75_fs0` | 94.42% | 10 |
| `ef21signmuon_unit-gain_e75_fs1` | 94.31% | 8 |
| `ef21signmuon_unit-gain_e75_fs2` | 94.21% | 9 |
| `muon_unit-gain_e75_fs0` | 94.12% | 8 |
| `muon_unit-gain_e75_fs1` | 94.65% | 7 |
| `muon_unit-gain_e75_fs2` | 94.28% | 8 |
| `muonsign_unit-gain_e75_fs0` | 93.45% | 16 |
| `muonsign_unit-gain_e75_fs1` | 93.40% | 17 |
| `muonsign_unit-gain_e75_fs2` | 93.07% | 20 |
| `muonusign_unit-gain_e75_fs0` | 94.11% | 10 |
| `muonusign_unit-gain_e75_fs1` | 93.96% | 10 |
| `muonusign_unit-gain_e75_fs2` | 93.88% | 11 |
| `sgd_unit-gain_e75_fs0` | 93.01% | 22 |
| `sgd_unit-gain_e75_fs1` | 92.92% | 20 |
| `sgd_unit-gain_e75_fs2` | 93.20% | 22 |
| `signmuon_unit-gain_e75_fs0` | 94.43% | 7 |
| `signmuon_unit-gain_e75_fs1` | 94.69% | 8 |
| `signmuon_unit-gain_e75_fs2` | 94.67% | 8 |
| `signsgd_unit-gain_e75_fs0` | 93.20% | 21 |
| `signsgd_unit-gain_e75_fs1` | 93.67% | 17 |
| `signsgd_unit-gain_e75_fs2` | 93.24% | 19 |

The paper's table, aggregated over seeds exactly as it defines them, is `table_cifar.csv` in `python3 -m centralized.export_article`.

## Weight-decay ablation (decoupled, wd = 0.0005)

The primary table above is unregularized (`--weight-decay 0`), which is the setting the theorems analyse and the one both reference implementations use. These runs repeat the best methods at seed 0 with decoupled decay on the matrix parameters, at the *same* eta_0. What matters is whether the ordering moves, not the absolute gain -- eta_0 was not re-tuned under decay.

| method | eta_0 | with decay | no decay | delta |
| :--- | ---: | ---: | ---: | ---: |
| `ef21signmuon` | 0.02 | 94.45% | 94.42% | +0.03 |
| `muon` | 0.1 | 94.46% | 94.12% | +0.34 |
| `signmuon` | 0.02 | 94.23% | 94.43% | -0.20 |

## What this run did NOT establish

* **Momentum (0.9) and weight decay (0) were held fixed** for every method, so this is a comparison at equal momentum, not at each method's own optimum.
* Weight decay is **decoupled** (`X *= 1 - lr*wd`, the LMO sees the true gradient). The coupled convention -- `wd*X` added to the gradient, which is what Mishra et al.'s Algorithm 1 and our own earlier numbers used -- is *not* an alternative worth reporting as an equal: every step direction here is scale-invariant, so coupled decay shrinks nothing and only rotates the direction. `--weight-decay-mode coupled` reproduces it for the appendix ablation.
* **A gap smaller than the seed spread is not a result.** Add seeds with `--resume` and aggregate before claiming one.

## Next steps

125 jobs completed, 0 failed.

```bash
python3 -m centralized.overnight --device cuda:0 --resume   # continue
python3 -m centralized.export_article                # pack results/article_export.tar.gz
```

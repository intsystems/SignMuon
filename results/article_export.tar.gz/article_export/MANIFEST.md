# Centralized results export

* source: `results/centralized`
* runs found: 126
* unreadable: 0
* targets for `epochs_to_*`: 90%, 93%, 94%

## Files

| file | bytes | contents |
| :--- | ---: | :--- |
| `runs.csv` | 34143 | one row per run: config + derived summary metrics |
| `curves.csv` | 1333513 | tidy per-epoch series for the figures |
| `table_cifar.csv` | 1455 | **the paper's table**: mean +/- sample std over seeds |
| `gain.csv` | 9802 | accumulated-gain series (`--log-gain` runs only) |
| `gain_fits.csv` | 480 | log-log slope of gain_median vs epoch |
| `environment.json` | 7468 | every machine that contributed: GPU, CUDA, Python, torch |
| `hardware.tex` | 389 | the same as a LaTeX row for the reproducibility appendix |
| `configs.json` | 214055 | full config of every run |
| `overnight/REPORT.md` | 6112 | copied verbatim |
| `overnight/state.json` | 124657 | copied verbatim |

## Notes

* Accuracies are percentages. `*_tail` is the mean of the final `last_k`
  recorded epochs -- the paper's primary metric -- not a single epoch.
* `val_*` is empty for `split=full` runs, which have no validation set;
  `test_acc` on `split=tune` runs comes from a 45k-trained model and was
  never used for selection.
* `epochs_to_*` is recomputed from the history here, so it does not depend
  on the training logs having been kept.
* Reported configurations carry 1, 3 seed(s). `test_acc_std` is a *sample* std and is empty at one seed --
  a single seed measured no dispersion; do not read a blank as agreement.
* Redraw every figure from this bundle with
  `python3 -m centralized.plot_analysis --bundle <this directory>`.

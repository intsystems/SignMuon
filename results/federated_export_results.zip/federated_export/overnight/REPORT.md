# Federated overnight run report

* started `2026-07-31T02:33:22`, wall clock 9:33:06 elapsed, 14:26:53 left
* device `cuda:0`, cnn2/cifar10, N=11 clients x 3 local steps, batch 64, `homo` split, measured **0.117 s/round** amortized
* scaling rule **`unit-gain`**, lr_aux = 0.001, momentum 0.9, weight decay 0 (decoupled; sgd coupled)
* tuning: 2000 rounds on the 45k/5k split, selected on **val_acc** (tail mean of the last 5 of 20 evaluations); **no test image is ever scored by a tuning run**
* finals: 2000 rounds on the full 50k, seeds [0, 1, 2, 3, 4]

## Tuned eta_0 (validation)

| method | family | eta_0 | val acc | configs | note |
| :--- | :--- | ---: | ---: | ---: | :--- |
| `signmuon` | sign | 0.1 | 84.72% | 7 |  |
| `muonusign` | lmo | 0.05 | 84.25% | 5 |  |
| `muonsign` | sign | 0.02 | 81.47% | 5 |  |
| `ef21signmuon` | lmo | 0.02 | 84.62% | 5 |  |
| `ef21muonusign` | lmo | 0.01 | 83.14% | 5 |  |
| `ef21muonsign` | lmo | 0.05 | 83.80% | 5 |  |
| `muon` | lmo | 0.1 | 85.51% | 5 |  |
| `muonserver` | lmo | 0.05 | 85.46% | 5 |  |
| `signsgd` | sign | 0.01 | 80.45% | 5 |  |
| `sgd` | - | 0.05 | 80.94% | 5 |  |
| `adam` | - | 0.001 | 76.66% | 5 |  |
| `adam+scaled` | sign | 0.05 | 77.46% | 5 |  |

A `BOUNDARY` note means the optimum sat on a grid endpoint: extend the grid and re-run that method before reporting it.

The rule's falsifiable prediction is that `eta_0` agrees *within* each family once the shape dependence lives in `lambda`. Check the `family` column against the rates.

## Horizon stability

Not applicable: rates were selected at 2000 rounds, the same horizon the table reports, so there is no proxy to check.

## Final runs (full 50k, test set)

| run | test acc (tail mean) | rounds to target | comm. saving (round trip) | MV ties | gain spread |
| :--- | ---: | ---: | ---: | ---: | ---: |
| `adam_scaled_unit-gain_e2000_fs0` | 77.84% | - | 1.0x | - | - |
| `adam_scaled_unit-gain_e2000_fs1` | 78.75% | - | 1.0x | - | - |
| `adam_scaled_unit-gain_e2000_fs2` | 79.71% | - | 1.0x | - | - |
| `adam_scaled_unit-gain_e2000_fs3` | 78.19% | - | 1.0x | - | - |
| `adam_scaled_unit-gain_e2000_fs4` | 76.66% | - | 1.0x | - | - |
| `adam_unit-gain_e2000_fs0` | 76.59% | - | 1.0x | - | - |
| `adam_unit-gain_e2000_fs1` | 77.56% | - | 1.0x | - | - |
| `adam_unit-gain_e2000_fs2` | 77.89% | - | 1.0x | - | - |
| `adam_unit-gain_e2000_fs3` | 78.02% | - | 1.0x | - | - |
| `adam_unit-gain_e2000_fs4` | 75.56% | - | 1.0x | - | - |
| `ef21muonsign_unit-gain_e2000_fs0` | 83.89% | 1000 | 29.4x | - | 1.01x |
| `ef21muonsign_unit-gain_e2000_fs1` | 84.43% | 1000 | 29.4x | - | 1.03x |
| `ef21muonsign_unit-gain_e2000_fs2` | 83.97% | 900 | 29.4x | - | 1.02x |
| `ef21muonsign_unit-gain_e2000_fs3` | 84.02% | 1000 | 29.4x | - | 1.05x |
| `ef21muonsign_unit-gain_e2000_fs4` | 83.65% | 1000 | 29.4x | - | 1.02x |
| `ef21muonusign_unit-gain_e2000_fs0` | 83.70% | 900 | 1.9x | - | 1.06x |
| `ef21muonusign_unit-gain_e2000_fs1` | 83.29% | 900 | 1.9x | - | 1.06x |
| `ef21muonusign_unit-gain_e2000_fs2` | 83.33% | 800 | 1.9x | - | 1.09x |
| `ef21muonusign_unit-gain_e2000_fs3` | 84.22% | 900 | 1.9x | - | 1.07x |
| `ef21muonusign_unit-gain_e2000_fs4` | 83.24% | 1000 | 1.9x | - | 1.02x |
| `ef21signmuon_unit-gain_e2000_fs0` | 84.68% | 700 | 1.9x | - | 1.08x |
| `ef21signmuon_unit-gain_e2000_fs1` | 84.47% | 700 | 1.9x | - | 1.09x |
| `ef21signmuon_unit-gain_e2000_fs2` | 84.77% | 600 | 1.9x | - | 1.09x |
| `ef21signmuon_unit-gain_e2000_fs3` | 84.77% | 600 | 1.9x | - | 1.09x |
| `ef21signmuon_unit-gain_e2000_fs4` | 84.88% | 600 | 1.9x | - | 1.11x |
| `muon_unit-gain_e2000_fs0` | 86.39% | 300 | 1.0x | - | 1.08x |
| `muon_unit-gain_e2000_fs1` | 85.97% | 200 | 1.0x | - | 1.11x |
| `muon_unit-gain_e2000_fs2` | 85.80% | 300 | 1.0x | - | 1.09x |
| `muon_unit-gain_e2000_fs3` | 86.05% | 200 | 1.0x | - | 1.10x |
| `muon_unit-gain_e2000_fs4` | 85.72% | 300 | 1.0x | - | 1.11x |
| `muonserver_unit-gain_e2000_fs0` | 85.61% | 400 | 1.0x | - | 1.13x |
| `muonserver_unit-gain_e2000_fs1` | 85.87% | 400 | 1.0x | - | 1.12x |
| `muonserver_unit-gain_e2000_fs2` | 85.81% | 400 | 1.0x | - | 1.16x |
| `muonserver_unit-gain_e2000_fs3` | 85.65% | 400 | 1.0x | - | 1.10x |
| `muonserver_unit-gain_e2000_fs4` | 85.75% | 400 | 1.0x | - | 1.11x |
| `muonsign_unit-gain_e2000_fs0` | 83.03% | 800 | 29.4x | 0.000 | 1.00x |
| `muonsign_unit-gain_e2000_fs1` | 83.05% | 900 | 29.4x | 0.000 | 1.00x |
| `muonsign_unit-gain_e2000_fs2` | 82.66% | 900 | 29.4x | 0.000 | 1.00x |
| `muonsign_unit-gain_e2000_fs3` | 82.86% | 900 | 29.4x | 0.000 | 1.00x |
| `muonsign_unit-gain_e2000_fs4` | 83.12% | 800 | 29.4x | 0.000 | 1.00x |
| `muonusign_unit-gain_e2000_fs0` | 84.97% | 600 | 1.9x | 0.000 | 1.05x |
| `muonusign_unit-gain_e2000_fs1` | 84.66% | 500 | 1.9x | 0.000 | 1.06x |
| `muonusign_unit-gain_e2000_fs2` | 84.20% | 400 | 1.9x | 0.000 | 1.09x |
| `muonusign_unit-gain_e2000_fs3` | 84.77% | 500 | 1.9x | 0.000 | 1.07x |
| `muonusign_unit-gain_e2000_fs4` | 84.20% | 500 | 1.9x | 0.000 | 1.08x |
| `sgd_unit-gain_e2000_fs0` | 82.04% | 1200 | 1.0x | - | 1.49x |
| `sgd_unit-gain_e2000_fs1` | 82.14% | 1100 | 1.0x | - | 1.30x |
| `sgd_unit-gain_e2000_fs2` | 81.49% | 1200 | 1.0x | - | 1.59x |
| `sgd_unit-gain_e2000_fs3` | 81.38% | 1300 | 1.0x | - | 1.39x |
| `sgd_unit-gain_e2000_fs4` | 81.38% | 1400 | 1.0x | - | 1.27x |
| `signmuon_unit-gain_e2000_fs0` | 85.47% | 600 | 29.4x | 0.000 | 1.00x |
| `signmuon_unit-gain_e2000_fs1` | 85.55% | 600 | 29.4x | 0.000 | 1.00x |
| `signmuon_unit-gain_e2000_fs2` | 86.09% | 500 | 29.4x | 0.000 | 1.00x |
| `signmuon_unit-gain_e2000_fs3` | 85.65% | 500 | 29.4x | 0.000 | 1.00x |
| `signmuon_unit-gain_e2000_fs4` | 85.81% | 500 | 29.4x | 0.000 | 1.00x |
| `signsgd_unit-gain_e2000_fs0` | 81.60% | 1100 | 29.4x | 0.000 | 1.00x |
| `signsgd_unit-gain_e2000_fs1` | 81.51% | 1100 | 29.4x | 0.000 | 1.00x |
| `signsgd_unit-gain_e2000_fs2` | 81.22% | 1200 | 29.4x | 0.000 | 1.00x |
| `signsgd_unit-gain_e2000_fs3` | 81.37% | 1100 | 29.4x | 0.000 | 1.00x |
| `signsgd_unit-gain_e2000_fs4` | 81.48% | 1200 | 29.4x | 0.000 | 1.00x |

Aggregate across seeds with `python3 -m aggregate --root results/federated`.

**comm. saving** is the *round-trip* reduction against full precision, with the uncompressed auxiliary group counted in (the sign alphabet is a genuine 1 bit under the randomized-zero convention). On CNN2 it is 1.9x for the three uplink-only methods -- MuonUSign, EF21-SignMuon and EF21-MuonUSign still broadcast a full-precision model every round -- and 29.4x for the four that are 1 bit in both directions (SignMuon, MuonSign, EF21-MuonSign, SignSGD). **Quote this number, not the uplink-only one.**

**gain spread** is `max/min` over layers of the realized `||lambda*s||_F/sqrt(fan_out)`. The per-layer rule targets 1.00x. The sign family is flat by construction; the LMO family inherits the Newton-Schulz norm error, which is shape-dependent and so is not absorbable into a single tuned `eta_0`.

**MV ties** is the fraction of coordinates where the RAW vote came out exactly zero, counted before any tie-break. Under the randomized-zero convention client messages are +-1, so at an odd `N` the vote cannot actually tie. This run used **N = 11** (odd).

## Per-layer rule ablation (sign family)

Each (method, rule) pair is re-tuned from scratch, then run at the final horizon. What matters is whether the *ordering* of the methods changes with the rule, not whether `eta_0` does -- it should, by roughly the multiplier the rule prescribes.

| method | rule | eta_0 | val @ tune | test acc (finals) | seeds |
| :--- | :--- | ---: | ---: | ---: | ---: |
| `signmuon` | **unit-gain** | 0.1 | 84.72% | 85.71% | 5 |
| `signmuon` | mup | 2 | 85.02% | 85.52% | 3 |
| `signmuon` | none | 0.002 | 85.42% | 85.68% | 3 |
| `muonsign` | **unit-gain** | 0.02 | 81.47% | 82.94% | 5 |
| `muonsign` | mup | 0.5 | 81.94% | 82.37% | 3 |
| `muonsign` | none | 0.001 | 81.78% | 82.26% | 3 |
| `signsgd` | **unit-gain** | 0.01 | 80.45% | 81.44% | 5 |
| `signsgd` | mup | 0.5 | 80.92% | 81.47% | 3 |
| `signsgd` | none | 0.0005 | 81.42% | 81.37% | 3 |

## Weight-decay ablation (decoupled, wd = 0.0005)

| method | eta_0 | with decay | no decay | delta |
| :--- | ---: | ---: | ---: | ---: |
| `muon` | 0.1 | 86.07% | 86.39% | -0.32 |
| `muonserver` | 0.05 | 85.66% | 85.61% | +0.05 |
| `signmuon` | 0.1 | 85.75% | 85.47% | +0.28 |

## What this run did NOT establish

* **`lr_aux` was fixed at 0.001**, not tuned. The auxiliary group is AdamW on the same parameters for every method, so its optimum should not depend on the matrix rule -- but that is an argument, not a measurement. Check it with `python3 -m federated.tune --stage aux`.
* **One federation scale** (N=11, 3 local steps) and one partition (`homo`). The paper's Experiment 1 (N=3) is not covered here.
* **BatchNorm running statistics are never updated from data.** Local models are discarded each round and BN runs in inference mode during accumulation, so the statistics stay at their initialization `(0, 1)` for the whole run, in training and evaluation alike. This is self-consistent but it needs a sentence in the reproducibility appendix.
* **A gap smaller than the seed spread is not a result.** Add seeds with `--resume --max-final-seeds 5` and aggregate before claiming one.

## Next steps

173 jobs completed, 0 failed. Resume with:

```bash
python3 -m federated.overnight --device cuda:0 --resume
```
